# Procedural-Planets
Simple procedural planet generation in Unity.
Watch tutorial series [here](https://www.youtube.com/watch?v=QN39W020LqU&index=2&t=0s&list=PLFt_AvWsXl0cONs3T0By4puYy6GM22ko8).
